package com.mygg.mygg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyggApplicationTests {

	@Test
	void contextLoads() {
	}

}
