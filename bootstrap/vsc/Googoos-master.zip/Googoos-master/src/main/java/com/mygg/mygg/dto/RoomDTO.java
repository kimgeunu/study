package com.mygg.mygg.dto;

import lombok.Data;

@Data
public class RoomDTO {
    int roomNumber;
    String Roomname;
}